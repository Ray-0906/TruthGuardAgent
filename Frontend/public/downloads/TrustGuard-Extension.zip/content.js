console.log("TruthGuard content script loaded");let x=!1,l=null,s=null,g=0,y=0,h=!1,b=null;chrome.runtime.onMessage.addListener((e,i,t)=>{if(e.action==="scrapePage"){const r=A();t({success:!0,data:r})}else if(e.action==="getSelectedText"){const r=window.getSelection().toString().trim();t(r?{success:!0,text:r,title:document.title,url:window.location.href}:{success:!1,message:"No text selected"})}else e.action==="enableSelection"?(T(),t({success:!0})):e.action==="disableSelection"&&(m(),t({success:!0}));return!0});window.addEventListener("message",e=>{e.data.type==="TRUTHGUARD_ENABLE_SELECTION"&&T()});function A(){const e=document.title,i=window.location.href;let t="";const r=["article",'[role="article"]',".article-content",".post-content",".entry-content","main",".main-content","#content"];for(const n of r){const c=document.querySelector(n);if(c){t=c.innerText;break}}t||(t=document.body.innerText);const o=5e3;return t.length>o&&(t=t.substring(0,o)+"..."),{title:e,url:i,text:t,timestamp:new Date().toISOString()}}function T(){if(x)return;x=!0,l=document.createElement("div"),l.id="truthguard-selection-overlay",l.style.cssText=`
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.3);
    z-index: 999999;
    cursor: crosshair;
  `;const e=document.createElement("div");e.style.cssText=`
    position: fixed;
    top: 20px;
    left: 50%;
    transform: translateX(-50%);
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 16px 24px;
    border-radius: 12px;
    font-family: Arial, sans-serif;
    font-size: 14px;
    font-weight: 600;
    box-shadow: 0 8px 16px rgba(0,0,0,0.3);
    z-index: 1000001;
    display: flex;
    align-items: center;
    gap: 12px;
  `,e.innerHTML=`
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
      <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
      <path d="M3 9h18"></path>
    </svg>
    <span>Click and drag to select an area to verify • Press ESC to cancel</span>
  `,l.appendChild(e),s=document.createElement("div"),s.style.cssText=`
    position: fixed;
    border: 3px dashed #667eea;
    background: rgba(102, 126, 234, 0.1);
    display: none;
    z-index: 1000000;
    pointer-events: none;
  `,l.appendChild(s),document.body.appendChild(l),l.addEventListener("mousedown",L),l.addEventListener("mousemove",z),l.addEventListener("mouseup",F),document.addEventListener("keydown",E)}function L(e){h=!0,g=e.clientX,y=e.clientY,s.style.left=g+"px",s.style.top=y+"px",s.style.width="0px",s.style.height="0px",s.style.display="block"}function z(e){if(!h)return;const i=e.clientX,t=e.clientY,r=Math.abs(i-g),o=Math.abs(t-y),n=Math.min(i,g),c=Math.min(t,y);s.style.width=r+"px",s.style.height=o+"px",s.style.left=n+"px",s.style.top=c+"px"}async function F(e){if(!h)return;h=!1;const i=s.getBoundingClientRect();if(i.width<50||i.height<50){m();return}const t=P(i);R();try{const r=await fetch("http://34.122.181.2:8080/verify_for_frontend_extension_app",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:t})});if(!r.ok)throw new Error(`API request failed: ${r.statusText}`);const o=await r.json();console.log("Selection API response:",o),b={text:t,url:window.location.href,title:document.title,timestamp:new Date().toISOString(),result:o},I(o),setTimeout(()=>{m()},1e4)}catch(r){console.error("Selection API error:",r),_(r.message),setTimeout(()=>{m()},5e3)}}function E(e){e.key==="Escape"&&m()}function P(e){const i=document.elementsFromPoint(e.left+e.width/2,e.top+e.height/2);let t="";for(const r of i)if(r.innerText){t=r.innerText;break}return t||"Selected area content"}function R(){s.innerHTML=`
    <div style="
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      height: 100%;
      background: rgba(255, 255, 255, 0.95);
      border-radius: 8px;
    ">
      <div style="
        width: 40px;
        height: 40px;
        border: 4px solid #e5e7eb;
        border-top-color: #3b82f6;
        border-radius: 50%;
        animation: spin 1s linear infinite;
      "></div>
      <p style="
        margin-top: 16px;
        color: #1f2937;
        font-family: Arial, sans-serif;
        font-size: 14px;
        font-weight: 600;
      ">Analyzing...</p>
    </div>
    <style>
      @keyframes spin {
        to { transform: rotate(360deg); }
      }
    </style>
  `}function I(e){const i=(e==null?void 0:e.result)||e||{},t=(e==null?void 0:e.formatted_response)||(i==null?void 0:i.raw_final)||"";let r=u(t,"Verdict");r||(r=i==null?void 0:i.verdict);const o=(r||"unverified").toString().toLowerCase();let n=u(t,"Confidence")||u(t,"Confidence Score");if(n!==void 0){const C=(n+"").match(/[\d.]+/);C&&(n=parseFloat(C[0]))}n==null&&(n=i==null?void 0:i.confidence);const c=typeof n=="number"?Math.round(n<=1?n*100:n):85,d=(i==null?void 0:i.summary)||M(t)||"Verification complete.",f=o.includes("true"),a=o.includes("false"),w=f?"#dcfce7":a?"#fee2e2":"#fef3c7",p=f?"#22c55e":a?"#ef4444":"#f59e0b",v=f?"#166534":a?"#991b1b":"#92400e",$=f?"✓":a?"✗":"⚠";s.style.pointerEvents="auto",s.innerHTML=`
    <div style="
      display: flex;
      flex-direction: column;
      height: 100%;
      background: ${w};
      border: 3px solid ${p};
      border-radius: 8px;
      padding: 20px;
      overflow: auto;
    ">
      <div style="
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 12px;
      ">
        <div style="
          width: 48px;
          height: 48px;
          background: ${p};
          color: white;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 28px;
          font-weight: bold;
        ">${$}</div>
        <div>
          <h3 style="
            margin: 0;
            color: ${v};
            font-family: Arial, sans-serif;
            font-size: 18px;
            font-weight: bold;
            text-transform: capitalize;
          ">${o}</h3>
          <p style="
            margin: 4px 0 0 0;
            color: ${v};
            font-family: Arial, sans-serif;
            font-size: 12px;
          ">Confidence: ${c}%</p>
        </div>
      </div>
      <p style="
        margin: 0;
        color: ${v};
        font-family: Arial, sans-serif;
        font-size: 13px;
        line-height: 1.5;
      ">${d}</p>
      
      <!-- Download Button -->
      <button id="truthguard-download-btn" style="
        margin-top: 16px;
        padding: 10px 16px;
        background: #3b82f6;
        color: white;
        border: none;
        border-radius: 6px;
        font-family: Arial, sans-serif;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 8px;
        justify-content: center;
        transition: background 0.2s;
      " onmouseover="this.style.background='#2563eb'" onmouseout="this.style.background='#3b82f6'">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
          <polyline points="7 10 12 15 17 10"></polyline>
          <line x1="12" y1="15" x2="12" y2="3"></line>
        </svg>
        Download Report (PDF)
      </button>
      
      <p style="
        margin-top: 12px;
        padding-top: 12px;
        border-top: 2px solid ${p};
        color: #6b7280;
        font-family: Arial, sans-serif;
        font-size: 11px;
      ">Auto-closes in 10 seconds • Press ESC to close</p>
    </div>
  `;const k=s.querySelector("#truthguard-download-btn");k&&k.addEventListener("click",B)}function _(e){const i="#fee2e2",t="#ef4444",r="#991b1b";s.style.pointerEvents="auto",s.innerHTML=`
    <div style="
      display: flex;
      flex-direction: column;
      height: 100%;
      background: ${i};
      border: 3px solid ${t};
      border-radius: 8px;
      padding: 20px;
      overflow: auto;
    ">
      <div style="
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 12px;
      ">
        <div style="
          width: 48px;
          height: 48px;
          background: ${t};
          color: white;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 28px;
          font-weight: bold;
        ">✗</div>
        <div>
          <h3 style="
            margin: 0;
            color: ${r};
            font-family: Arial, sans-serif;
            font-size: 18px;
            font-weight: bold;
          ">Error</h3>
        </div>
      </div>
      <p style="
        margin: 0;
        color: ${r};
        font-family: Arial, sans-serif;
        font-size: 13px;
        line-height: 1.5;
      ">${e||"Failed to verify the selected content. Please try again."}</p>
      
      <p style="
        margin-top: 12px;
        padding-top: 12px;
        border-top: 2px solid ${t};
        color: #6b7280;
        font-family: Arial, sans-serif;
        font-size: 11px;
      ">Auto-closes in 5 seconds • Press ESC to close</p>
    </div>
  `}function S(e){return typeof e=="string"?e.replace(/^```(?:[\w-]+)?\n/,"").replace(/\n```$/,""):""}function u(e,i){if(!e)return;const t=S(e),r=new RegExp(`\\*+\\s*${i}\\s*\\*+[:：]?\\s*([^
\r]+)`,"i");let o=t.match(r);if(o&&o[1])return o[1].trim();const n=t.replace(/\*/g,""),c=new RegExp(`^\\s*${i}\\s*[:：]\\s*([^
\r]+)`,"im");if(o=n.match(c),o&&o[1])return o[1].trim();const d=new RegExp(`${i}\\s*[:：]?\\s*([\\d\\.]+|\\w+)`,"i");if(o=t.match(d),o&&o[1])return o[1].trim()}function M(e){if(!e)return;const t=S(e).split(/\r?\n/),r=t.findIndex(n=>n.trim().toLowerCase().startsWith("### summary")||n.trim().toLowerCase().startsWith("## summary"));if(r===-1)return;const o=[];for(let n=r+1;n<t.length&&!/^###?\s+/.test(t[n]);n++)t[n].trim()&&o.push(t[n].trim());return o.join(" ").trim()}async function B(){if(!b)return;const{text:e,url:i,title:t,timestamp:r,result:o}=b,n=(o==null?void 0:o.result)||o||{},c=(o==null?void 0:o.formatted_response)||(n==null?void 0:n.raw_final)||"";let d=u(c,"Verdict");d||(d=n==null?void 0:n.verdict);const f=(d||"unverified").toString();let a=u(c,"Confidence")||u(c,"Confidence Score");if(a!==void 0){const p=(a+"").match(/[\d.]+/);p&&(a=parseFloat(p[0]))}a===void 0&&(a=n==null?void 0:n.confidence);const w=typeof a=="number"?Math.round(a<=1?a*100:a):0;chrome.runtime.sendMessage({action:"generatePDF",data:{title:"TruthGuard Fact Check Report (Selection)",pageTitle:t,url:i,scannedAt:new Date(r).toLocaleString(),content:e.substring(0,1e3),verdict:f,confidence:w,summary:(n==null?void 0:n.summary)||M(c)||"Verification complete.",fullReport:S(c),mode:"selection"}})}function m(){x&&(x=!1,h=!1,b=null,l&&(l.remove(),l=null),s=null,document.removeEventListener("keydown",E))}
